#pragma once
// Fast drawing for the DIYables 8-bit parallel TFT on UNO Q.
//
// The DIYables library drives the bus with ~20 digitalWrite() calls per pixel
// on UNO Q, which is too slow for 40 moving sprites. After the library has
// initialised the panel, this class writes the same bus through the STM32
// GPIO set/reset registers instead. Set DUCKS_FAST_BUS to 0 to fall back to
// the library's own (slow but known-good) path.

#include <Arduino.h>
#include <Adafruit_GFX.h>
#include <DIYables_TFT_Touch_Shield.h>

#ifndef DUCKS_FAST_BUS
#define DUCKS_FAST_BUS 1
#endif

namespace fastbus {

// STM32U585 GPIO BSRR registers (non-secure aliases; TrustZone is off on UNO Q).
static volatile uint32_t* const kPortA = reinterpret_cast<volatile uint32_t*>(0x42020000u + 0x18u);
static volatile uint32_t* const kPortB = reinterpret_cast<volatile uint32_t*>(0x42020400u + 0x18u);

// Control lines, from the UNO Q Zephyr variant: A1 = PA5 (WR), A2 = PA6 (C/D).
constexpr uint32_t kWr = 1u << 5;
constexpr uint32_t kCd = 1u << 6;

// Bus bit -> STM32 pin. Bus bits 0..7 are UNO pins D8, D9, D2..D7.
// D8=PB4 D9=PB8 D2=PB3 D3=PB0 D4=PA12 D5=PA11 D6=PB1 D7=PB2.
constexpr int8_t kBitPortBPin[8] = {4, 8, 3, 0, -1, -1, 1, 2};
constexpr int8_t kBitPortAPin[8] = {-1, -1, -1, -1, 12, 11, -1, -1};

static uint32_t lutA[256];
static uint32_t lutB[256];

inline void init() {
  uint32_t maskA = 0, maskB = 0;
  for (int bit = 0; bit < 8; ++bit) {
    if (kBitPortAPin[bit] >= 0) maskA |= 1u << kBitPortAPin[bit];
    if (kBitPortBPin[bit] >= 0) maskB |= 1u << kBitPortBPin[bit];
  }
  for (int value = 0; value < 256; ++value) {
    uint32_t setA = 0, setB = 0;
    for (int bit = 0; bit < 8; ++bit) {
      if (!(value & (1 << bit))) continue;
      if (kBitPortAPin[bit] >= 0) setA |= 1u << kBitPortAPin[bit];
      if (kBitPortBPin[bit] >= 0) setB |= 1u << kBitPortBPin[bit];
    }
    // BSRR: low half sets pins, high half clears them.
    lutA[value] = setA | ((maskA & ~setA) << 16);
    lutB[value] = setB | ((maskB & ~setB) << 16);
  }
}

// The panel latches data on the rising edge of WR; the NOPs keep the low and
// high phases comfortably above the controller's minimum pulse widths.
inline void strobe() {
  *kPortA = kWr << 16;
  __asm volatile("nop\n\tnop\n\tnop\n\tnop\n\tnop\n\tnop");
  *kPortA = kWr;
  __asm volatile("nop\n\tnop\n\tnop\n\tnop");
}

inline void write(uint8_t value) {
  *kPortB = lutB[value];
  *kPortA = lutA[value] | (kWr << 16);  // Data on port A and WR low together.
  __asm volatile("nop\n\tnop\n\tnop\n\tnop\n\tnop\n\tnop");
  *kPortA = kWr;
  __asm volatile("nop\n\tnop\n\tnop\n\tnop");
}

inline void command(uint8_t cmd) {
  *kPortA = kCd << 16;
  write(cmd);
  *kPortA = kCd;  // Leave C/D high: everything after a command is data.
}

}  // namespace fastbus

class Screen : public Adafruit_GFX {
 public:
  explicit Screen(DIYables_TFT_Touch_Shield_Base& tft) : Adafruit_GFX(480, 320), tft_(tft) {}

  // Call after tft.begin() and tft.setRotation(1).
  void begin() {
#if DUCKS_FAST_BUS
    fastbus::init();
#endif
  }

  void drawPixel(int16_t x, int16_t y, uint16_t color) override {
    if (x < 0 || y < 0 || x >= _width || y >= _height) return;
    window(x, y, x, y);
    fill(color, 1);
  }

  void fillRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color) override {
    if (x < 0) { w += x; x = 0; }
    if (y < 0) { h += y; y = 0; }
    if (x + w > _width) w = _width - x;
    if (y + h > _height) h = _height - y;
    if (w <= 0 || h <= 0) return;
    window(x, y, x + w - 1, y + h - 1);
    fill(color, (uint32_t)w * h);
  }

  void drawFastHLine(int16_t x, int16_t y, int16_t w, uint16_t color) override { fillRect(x, y, w, 1, color); }
  void drawFastVLine(int16_t x, int16_t y, int16_t h, uint16_t color) override { fillRect(x, y, 1, h, color); }
  void fillScreen(uint16_t color) override { fillRect(0, 0, _width, _height, color); }

  // Copy a w*h RGB565 image. The caller keeps it fully on screen.
  void blit(int16_t x, int16_t y, int16_t w, int16_t h, const uint16_t* pixels) {
    window(x, y, x + w - 1, y + h - 1);
    uint32_t count = (uint32_t)w * h;
#if DUCKS_FAST_BUS
    while (count--) {
      uint16_t c = *pixels++;
      fastbus::write(c >> 8);
      fastbus::write(c & 0xFF);
    }
#else
    tft_.pushColors(const_cast<uint16_t*>(pixels), count);
#endif
  }

 private:
  void window(int16_t x0, int16_t y0, int16_t x1, int16_t y1) {
#if DUCKS_FAST_BUS
    fastbus::command(0x2A);
    fastbus::write(x0 >> 8); fastbus::write(x0 & 0xFF);
    fastbus::write(x1 >> 8); fastbus::write(x1 & 0xFF);
    fastbus::command(0x2B);
    fastbus::write(y0 >> 8); fastbus::write(y0 & 0xFF);
    fastbus::write(y1 >> 8); fastbus::write(y1 & 0xFF);
    fastbus::command(0x2C);
#else
    tft_.setAddrWindow(x0, y0, x1, y1);
#endif
  }

  void fill(uint16_t color, uint32_t count) {
#if DUCKS_FAST_BUS
    uint8_t hi = color >> 8, lo = color & 0xFF;
    if (hi == lo) {  // White and black: set the bus once, then only strobe.
      *fastbus::kPortB = fastbus::lutB[hi];
      *fastbus::kPortA = fastbus::lutA[hi];
      while (count--) { fastbus::strobe(); fastbus::strobe(); }
    } else {
      while (count--) { fastbus::write(hi); fastbus::write(lo); }
    }
#else
    static uint16_t chunk[64];
    for (int i = 0; i < 64; ++i) chunk[i] = color;
    while (count) {
      uint32_t n = count > 64 ? 64 : count;
      tft_.pushColors(chunk, n);
      count -= n;
    }
#endif
  }

  DIYables_TFT_Touch_Shield_Base& tft_;
};

// Duck Duck Punch: 40 identical ducks on the grass. One of them is you.
//
// HUNT   (solo) One target duck. You only get a hint about its habit
//        ("loves to run", "picks fights"...). Find yourself, find it, punch it.
// SCORE  (solo) Three targets in a row, but only 15 punches for the round.
// ONLINE Two consoles on the same hotspot. Each console controls one duck.
//        Find yourself, find the other player, punch them. Last duck wins.
//
// Ordinary ducks punch now and then too, so a vanishing duck proves nothing,
// and any duck - player or not - can be knocked out by a stray punch.
//
// Controls on every console: stick or tilt to move, B to dash, A to punch,
// C to leave the round (online, the other console sees CONNECTION LOST).
// Nothing on screen ever marks your own duck until the round is over.
//
// The game runs on the MCU at ~30 ticks per second. In ONLINE mode the host
// console simulates the world; Python on each MPU relays the other player's
// input and world snapshots over the network (see python/main.py).

#include <Arduino.h>
#include <Arduino_RouterBridge.h>
#include <Arduino_Modulino.h>
#include <DIYables_TFT_Touch_Shield.h>
#include <math.h>
#include "screen.h"
#include "sprites.h"

#if !defined(ARDUINO_UNO_Q)
#error "Select Arduino UNO Q for this game."
#endif

// 1 for HX8357D (default console), 0 for RM68140.
#ifndef ARCADE_TFT_HX8357D
#define ARCADE_TFT_HX8357D 1
#endif
#if ARCADE_TFT_HX8357D
DIYables_TFT_HX8357D_Shield display;
#else
DIYables_TFT_RM68140_Shield display;
#endif
Screen gfx(display);

// ---------------------------------------------------------------- tuning

constexpr int kScreenW = 480;
constexpr int kScreenH = 320;
constexpr int kHudH = 26;
constexpr int kDucks = 40;            // Includes the players.
constexpr int kTickMs = 33;
constexpr int kTps = 30;
constexpr int kRoundSeconds = 180;
constexpr int kCountdownSeconds = 3;      // Online.
constexpr int kSoloCountdownSeconds = 6;  // Solo: time to read the target's habit.
constexpr int kNewTargetHintSeconds = 5;  // SCORE: how long a new target's hint shows.
constexpr int kStepPixels = 5;            // Feet switch every this many pixels walked.
constexpr int kPunchReach = 28;       // Centre-to-centre distance in pixels.
constexpr int kCooldownTicks = 15;
constexpr int kScoreTargets = 3;      // SCORE mode: targets to find...
constexpr int kScorePunches = 15;     // ...with this many punches.
constexpr int kFighterChance = 8;     // % per second a fighter target punches a neighbour.
constexpr int kNpcPunchSeconds = 10;  // On average one ordinary duck punches this often.
constexpr int kDashMax = 30;          // One second of dash at full stamina.
constexpr int kDashMin = 8;
constexpr int kStickThreshold = 45;   // Raw stick units, -127..128.
constexpr int kTiltThresholdMg = 170;  // Used until TILT SETUP has been run.
constexpr int kTiltMinRecordMg = 150;  // TILT SETUP rejects smaller tilts.

constexpr uint8_t kButtonsAddress = 0x3E;
constexpr uint8_t kJoystickAddress = 0x2C;
constexpr int kMissingAfterFailures = 6;

// ---------------------------------------------------------------- state

ModulinoButtons buttons(kButtonsAddress);
ModulinoMovement movement;
bool movementReady = false;

enum Held : uint8_t { kA = 1, kB = 2, kC = 4, kStick = 8 };

struct Inputs {
  bool buttonsOk = false, stickOk = false, imuOk = false;
  uint8_t held = 0;
  int sx = 0, sy = 0;  // Stick, right and up positive.
  int a[3] = {0, 0, 0};  // Acceleration x, y, z in mg.
};

// What one player asks for this tick, wherever the player is.
struct Command {
  int8_t dx = 0, dy = 0;
  bool dash = false;
  bool punch = false;  // A newly pressed.
};

struct Duck {
  int16_t x, y;        // Top-left of the 16x14 sprite.
  int8_t dx, dy;
  uint8_t speed;
  uint16_t timer;
  bool alive, left;
  // What is currently on the screen for this duck.
  int16_t shownX, shownY;
  uint8_t steps;        // Pixels walked, for the feet animation.
  bool shown, shownLeft, redraw;
  uint8_t shownFrame;
};

struct Player {
  int duck;
  int cooldown, dash;
  bool dashing, alive;
};

enum Phase : uint8_t { kTitle, kWait, kCountdown, kPlay, kOver, kTiltSetup };
enum Mode : uint8_t { kNone, kSolo, kHost, kClient };
enum Result : uint8_t {
  kP1Wins = 0, kP2Wins = 1, kTimeUp = 2, kLinkLost = 3,
  kOutOfPunches = 4, kTargetGotYou = 5, kDuckGotYou = 6,  // SOLO only.
  kNoResult = 0xFF
};
enum SoloKind : uint8_t { kHunt, kScore };

// A solo target's habit. Each one only nudges the odds by a few percent.
enum Trait : uint8_t { kRunner, kWalker, kTurner, kFighter, kTraitCount };
const char* const kTraitHint[kTraitCount] = {
    "TARGET loves to run", "TARGET never stops walking", "TARGET can't walk straight",
    "TARGET picks fights. Careful!"};
const char* const kTraitTag[kTraitCount] = {"RUNNER", "WALKER", "TURNER", "FIGHTER"};

Duck ducks[kDucks];
Player players[2];
int playerCount = 1;
int targetDuck = -1;  // SOLO only.
SoloKind soloKind = kHunt;
Trait targetTrait = kRunner;
int targetsHit = 0, punchesLeft = 0;
uint32_t bannerUntil = 0;  // SCORE: tick until which the new-target hint shows.
Phase phase = kTitle;
Mode mode = kNone;
Result result = kNoResult;
Inputs in;
uint8_t prevHeld = 0;
uint8_t latchedPresses = 0;  // CLIENT: presses since Python last asked.
int failButtons = 0, failStick = 0, failImu = 0;
// Tilt: the round-start pose is "zero". The calibrated right and forward
// directions (unit vectors x1000, any mounting) turn a pose into steering.
int tiltZero[3] = {0, 0, 0};
int tiltRight[3] = {1000, 0, 0};
int tiltForward[3] = {0, -1000, 0};
int tiltThreshold = kTiltThresholdMg;
int calVersion = 0;  // Bumped after each TILT SETUP so Python saves it.
int setupStage = 0;
int setupZero[3], setupRight[3];
int setupDotX = -1, setupDotY = -1;
uint32_t tickCount = 0, phaseTick = 0, playTicks = 0;
uint32_t nextTickAt = 0, worstTickMs = 0;
int secondsLeft = 0, shownSeconds = -1;
Command remote;              // HOST: latest command from the client console.
bool remoteFresh = false;
bool remoteControlsOk = true;  // HOST: the client console's controls are usable.
// Why the round is frozen: a console's buttons are gone, or it has neither
// stick nor tilt. Online, either console's loss pauses both.
enum Pause : uint8_t { kNotPaused = 0, kPausedHere = 1, kPausedThere = 2 };
Pause pauseReason = kNotPaused;
uint32_t lastSnapshotAt = 0;  // CLIENT
uint8_t ledState = 0xFF;
uint8_t titleControls = 0xFF;
char statusLine[200] = "booting";

// [frame]: 0 = feet together, 1 = stepping.
uint16_t duckRight[2][kBoxW * kBoxH];
uint16_t duckLeft[2][kBoxW * kBoxH];

int countdownSeconds() { return mode == kSolo ? kSoloCountdownSeconds : kCountdownSeconds; }
uint8_t duckFrame(const struct Duck& d);

// ---------------------------------------------------------------- input

bool readPacket(uint8_t address, uint8_t payload[3]) {
  int count = Wire1.requestFrom(address, (uint8_t)4);
  if (count != 4) {
    while (Wire1.available()) Wire1.read();
    return false;
  }
  Wire1.read();  // Modulino pinstrap address precedes the three input bytes.
  for (int i = 0; i < 3; ++i) payload[i] = Wire1.read();
  return true;
}

// A single failed I2C read keeps the last value; only repeated failures
// count as a missing control.
uint32_t testDropUntil = 0;  // ducks_test_drop(): pretend the Buttons cable is out.

void readInputs() {
  uint8_t b[3] = {}, s[3] = {};
  bool simulatedDrop = (int32_t)(testDropUntil - millis()) > 0;
  if (!simulatedDrop && readPacket(kButtonsAddress, b)) {
    failButtons = 0;
    in.buttonsOk = true;
    in.held &= kStick;
    for (int i = 0; i < 3; ++i) if (b[i]) in.held |= 1 << i;
  } else if (++failButtons >= kMissingAfterFailures) {
    in.buttonsOk = false;
    in.held &= kStick;
  }

  if (readPacket(kJoystickAddress, s)) {
    failStick = 0;
    in.stickOk = true;
    in.sx = 128 - (int)s[0];
    in.sy = 128 - (int)s[1];
    in.held = (in.held & ~kStick) | (s[2] ? kStick : 0);
  } else if (++failStick >= kMissingAfterFailures) {
    in.stickOk = false;
    in.sx = in.sy = 0;
    in.held &= ~kStick;
  }

  bool imu = movementReady && movement.update();
  float g[3] = {0, 0, 0};
  if (imu) { g[0] = movement.getX(); g[1] = movement.getY(); g[2] = movement.getZ(); }
  if (imu && isfinite(g[0]) && isfinite(g[1]) && isfinite(g[2])) {
    failImu = 0;
    in.imuOk = true;
    for (int k = 0; k < 3; ++k) in.a[k] = (int)(constrain(g[k], -16.0f, 16.0f) * 1000);
  } else if (++failImu >= kMissingAfterFailures * 3) {
    in.imuOk = false;
  }
}

// Buttons are required; at least one of stick or tilt must work.
bool controlsReady() { return in.buttonsOk && (in.stickOk || in.imuOk); }

void setLeds(bool a, bool b, bool c) {
  uint8_t want = (a ? 1 : 0) | (b ? 2 : 0) | (c ? 4 : 0);
  if (want == ledState || !in.buttonsOk) return;
  buttons.setLeds(a, b, c);
  ledState = want;
}

// How far the console leans right (tx) and towards the player (ty, screen
// down), in mg, measured from `zero`.
//
// The recorded right and forward directions are rarely at exactly 90 degrees
// to each other, so the tilt is split into those two directions properly
// rather than projected onto each one; otherwise a hard forward tilt would
// also steer sideways.
void tiltFrom(const int zero[3], int& tx, int& ty) {
  float r = 0, f = 0, c = 0;
  for (int k = 0; k < 3; ++k) {
    float v = in.a[k] - zero[k];
    r += v * tiltRight[k] / 1000.0f;
    f += v * tiltForward[k] / 1000.0f;
    c += tiltRight[k] / 1000.0f * tiltForward[k] / 1000.0f;
  }
  float det = 1 - c * c;  // TILT SETUP keeps |c| <= 0.7, so det >= 0.51.
  if (det < 0.2f) det = 0.2f;
  tx = (int)((r - c * f) / det);
  ty = (int)(-(f - c * r) / det);  // Leaning away moves the duck up the screen.
}

void tiltVector(int& tx, int& ty) { tiltFrom(tiltZero, tx, ty); }

// Unit vector x1000 from `from` to `to`; returns the length in mg.
int unitBetween(const int from[3], const int to[3], int out[3]) {
  float d[3], len = 0;
  for (int k = 0; k < 3; ++k) { d[k] = to[k] - from[k]; len += d[k] * d[k]; }
  len = sqrtf(len);
  for (int k = 0; k < 3; ++k) out[k] = len > 1 ? (int)(d[k] * 1000 / len) : 0;
  return (int)len;
}

// The stick wins when it is pushed; otherwise tilting the console steers.
Command localCommand(uint8_t pressed) {
  Command c;
  if (in.stickOk && (abs(in.sx) > kStickThreshold || abs(in.sy) > kStickThreshold)) {
    c.dx = in.sx > kStickThreshold ? 1 : in.sx < -kStickThreshold ? -1 : 0;
    c.dy = in.sy > kStickThreshold ? -1 : in.sy < -kStickThreshold ? 1 : 0;  // Stick up = screen up.
  } else if (in.imuOk) {
    int tx, ty;
    tiltVector(tx, ty);
    c.dx = tx > tiltThreshold ? 1 : tx < -tiltThreshold ? -1 : 0;
    c.dy = ty > tiltThreshold ? 1 : ty < -tiltThreshold ? -1 : 0;
  }
  c.dash = in.held & kB;
  c.punch = pressed & kA;
  return c;
}

// ---------------------------------------------------------------- drawing

void centerText(int y, uint8_t size, uint16_t color, uint16_t bg, const char* text) {
  int w = strlen(text) * 6 * size;
  gfx.setTextSize(size);
  gfx.setTextColor(color, bg);
  gfx.setCursor((kScreenW - w) / 2, y);
  gfx.print(text);
}

void hudText(int x, uint16_t color, const char* text) {
  gfx.setTextSize(2);
  gfx.setTextColor(color, kWhite);
  gfx.setCursor(x, 5);
  gfx.print(text);
}

void hudLeft(const char* text) {
  gfx.fillRect(0, 0, 140, kHudH - 1, kWhite);
  hudText(8, kBlack, text);
}

void hudRight(uint16_t color, const char* text) {
  gfx.fillRect(kScreenW - 140, 0, 140, kHudH - 1, kWhite);
  hudText(kScreenW - 8 - strlen(text) * 12, color, text);
}

void hudCenter(uint16_t color, const char* text) {
  gfx.fillRect(140, 0, kScreenW - 280, kHudH - 1, kWhite);
  hudText((kScreenW - strlen(text) * 12) / 2, color, text);
}

// Results are longer than the centre slot, so they take the whole bar.
void hudBanner(uint16_t color, const char* text) {
  gfx.fillRect(0, 0, kScreenW, kHudH - 1, kWhite);
  hudText((kScreenW - strlen(text) * 12) / 2, color, text);
}

void drawHudScore() {
  if (mode != kSolo || soloKind != kScore || bannerUntil) return;
  char text[16];
  snprintf(text, sizeof(text), "%d/%d P%d", targetsHit, kScoreTargets, punchesLeft);
  hudRight(punchesLeft <= 3 ? kRed : kBlack, text);
}

void drawHudClock();

// Left: the target's habit (solo) or ONLINE. Centre: clock. Right: score.
void drawHudBar() {
  gfx.fillRect(0, 0, kScreenW, kHudH - 1, kWhite);
  hudLeft(mode == kSolo ? kTraitTag[targetTrait] : "ONLINE");
  shownSeconds = -1;
  drawHudClock();
  drawHudScore();
}

void drawArena() {
  gfx.drawFastHLine(0, kHudH - 1, kScreenW, kBlack);
  gfx.fillRect(0, kHudH, kScreenW, kScreenH - kHudH, kBg);
  for (auto& d : ducks) d.shown = false;
  bannerUntil = 0;
  drawHudBar();
}

void drawTitleControls() {
  uint8_t now = (in.buttonsOk ? 1 : 0) | (in.stickOk ? 2 : 0) | (in.imuOk ? 4 : 0);
  if (now == titleControls) return;
  titleControls = now;
  char line[48];
  snprintf(line, sizeof(line), "Buttons %s  Stick %s  Tilt %s", in.buttonsOk ? "OK" : "--",
           in.stickOk ? "OK" : "--", in.imuOk ? "OK" : "--");
  gfx.fillRect(0, 294, kScreenW, 20, kWhite);
  centerText(296, 2, controlsReady() ? kGreen : kRed, kWhite, line);
}

// Title screen: a row of ducks runs left to right across a strip of grass,
// feet stepping and bodies bobbing, and wraps around.
constexpr int kParadeTop = 50, kParadeH = 30, kParadeDucks = 10;
constexpr int kParadeSpacing = kScreenW / kParadeDucks;  // 48 px: boxes never overlap.
constexpr int kParadeSpeed = 2;                          // Pixels per tick: a run.
int paradeOffset = 0;
int paradeX[kParadeDucks], paradeY[kParadeDucks];
bool paradeShown[kParadeDucks];

void animateParade() {
  paradeOffset = (paradeOffset + kParadeSpeed) % kScreenW;
  for (int i = 0; i < kParadeDucks; ++i) {
    int x = (i * kParadeSpacing + paradeOffset) % kScreenW;
    bool visible = x >= kPad && x <= kScreenW - kDuckW - kPad;  // Off the edge while wrapping.
    uint8_t frame = (x / kStepPixels) & 1;
    int y = kParadeTop + 6 - frame;  // Bob up a pixel on each step.
    if (paradeShown[i] && (!visible || abs(x - paradeX[i]) > kPad)) {
      gfx.fillRect(paradeX[i] - kPad, paradeY[i] - kPad, kBoxW, kBoxH, kBg);
      paradeShown[i] = false;
    }
    if (!visible) continue;
    gfx.blit(x - kPad, y - kPad, kBoxW, kBoxH, duckRight[frame]);
    paradeX[i] = x;
    paradeY[i] = y;
    paradeShown[i] = true;
  }
}

void drawTitle() {
  gfx.fillScreen(kWhite);
  centerText(12, 4, kBlack, kWhite, "DUCK DUCK PUNCH");
  gfx.fillRect(0, kParadeTop, kScreenW, kParadeH, kBg);
  for (auto& shown : paradeShown) shown = false;
  centerText(90, 2, kBlack, kWhite, "40 ducks, one is you. Ducks punch too!");
  centerText(114, 2, kBlack, kWhite, "Move: stick or tilt  B dash  A punch");
  centerText(144, 2, kBlack, kWhite, "HUNT: 1 target, only a hint about");
  centerText(166, 2, kBlack, kWhite, "its habit. Find it and punch it.");
  centerText(192, 2, kBlack, kWhite, "SCORE: 3 targets, only 15 punches.");
  centerText(218, 2, kBlack, kWhite, "ONLINE: 2 consoles, punch the other.");
  centerText(240, 2, kBlack, kWhite, "3 minutes. No winner = you lose.");
  centerText(268, 2, kRed, kWhite, "A: HUNT   B: SCORE   C: ONLINE");
  titleControls = 0xFF;
  drawTitleControls();
}

// TILT SETUP: three presses of A record the playing pose, a right tilt and
// a forward tilt; then a dot follows the tilt so the result can be checked.
void enterTitle();

constexpr int kSetupBoxX = 140, kSetupBoxY = 170, kSetupBoxW = 200, kSetupBoxH = 110;

void drawTiltSetup(const char* note) {
  static const char* const steps[] = {
      "1. Hold it the way you play.", "2. Tilt it to the RIGHT.", "3. Tilt the TOP AWAY from you."};
  gfx.fillScreen(kWhite);
  centerText(16, 3, kBlack, kWhite, "TILT SETUP");
  if (setupStage < 3) {
    centerText(70, 2, kBlack, kWhite, steps[setupStage]);
    centerText(100, 2, kBlack, kWhite, "Hold still and press A.");
  } else {
    centerText(70, 2, kGreen, kWhite, "Saved! The dot follows your tilt.");
    centerText(100, 2, kBlack, kWhite, "A: start over   C: done");
  }
  if (note) centerText(134, 2, kRed, kWhite, note);
  if (setupStage == 3) gfx.drawRect(kSetupBoxX, kSetupBoxY, kSetupBoxW, kSetupBoxH, kBlack);
  setupDotX = -1;
}

void enterTiltSetup() {
  phase = kTiltSetup;
  setupStage = 0;
  drawTiltSetup(nullptr);
}

void tiltSetupTick(uint8_t pressed) {
  if (pressed & kC) { enterTitle(); return; }
  if (!in.imuOk) {
    if (pressed & kA) drawTiltSetup("Movement module not found");
    return;
  }
  if (setupStage == 3) {
    if (pressed & kA) { enterTiltSetup(); return; }
    int tx, ty;
    tiltFrom(setupZero, tx, ty);
    int cx = kSetupBoxX + kSetupBoxW / 2, cy = kSetupBoxY + kSetupBoxH / 2;
    int x = constrain(cx + tx * (kSetupBoxW / 2 - 8) / (2 * tiltThreshold), kSetupBoxX + 8, kSetupBoxX + kSetupBoxW - 8);
    int y = constrain(cy + ty * (kSetupBoxH / 2 - 8) / (2 * tiltThreshold), kSetupBoxY + 8, kSetupBoxY + kSetupBoxH - 8);
    if (x == setupDotX && y == setupDotY) return;
    if (setupDotX >= 0) gfx.fillCircle(setupDotX, setupDotY, 6, kWhite);
    // Inner box: the dead zone. Outside it the duck would walk.
    gfx.drawRect(cx - kSetupBoxW / 4, cy - kSetupBoxH / 4, kSetupBoxW / 2, kSetupBoxH / 2, kGray);
    gfx.fillCircle(x, y, 6, kRed);
    setupDotX = x;
    setupDotY = y;
    return;
  }
  if (!(pressed & kA)) return;
  if (setupStage == 0) {
    for (int k = 0; k < 3; ++k) setupZero[k] = in.a[k];
    setupStage = 1;
    drawTiltSetup(nullptr);
  } else if (setupStage == 1) {
    int unit[3];
    if (unitBetween(setupZero, in.a, unit) < kTiltMinRecordMg) { drawTiltSetup("Tilt a bit more, then press A"); return; }
    for (int k = 0; k < 3; ++k) setupRight[k] = in.a[k];
    setupStage = 2;
    drawTiltSetup(nullptr);
  } else {
    int right[3], forward[3];
    int rightLen = unitBetween(setupZero, setupRight, right);
    int forwardLen = unitBetween(setupZero, in.a, forward);
    long dot = 0;
    for (int k = 0; k < 3; ++k) dot += (long)right[k] * forward[k];
    if (forwardLen < kTiltMinRecordMg) { drawTiltSetup("Tilt a bit more, then press A"); return; }
    if (labs(dot) > 700000) { drawTiltSetup("That was sideways again - tilt AWAY"); return; }
    for (int k = 0; k < 3; ++k) { tiltRight[k] = right[k]; tiltForward[k] = forward[k]; }
    // Walking starts at 40% of the tilt you showed, so gentle players get gentle steering.
    tiltThreshold = constrain((int)(0.4f * min(rightLen, forwardLen)), 100, 400);
    ++calVersion;
    setupStage = 3;
    drawTiltSetup(nullptr);
  }
}

void drawWait() {
  gfx.fillScreen(kWhite);
  centerText(40, 3, kBlack, kWhite, "ONLINE");
  centerText(100, 2, kBlack, kWhite, "Looking for the other console...");
  centerText(140, 2, kBlack, kWhite, "Both consoles on the same hotspot,");
  centerText(164, 2, kBlack, kWhite, "both press C on the title screen.");
  centerText(220, 2, kRed, kWhite, "C: cancel");
}

bool boxesOverlap(int ax, int ay, int bx, int by) {
  return abs(ax - bx) < kBoxW && abs(ay - by) < kBoxH;
}

bool duckVisible(int i) { return ducks[i].alive; }

// Bring the screen in line with the duck table. Small moves are covered by
// the sprite's border; bigger jumps (client snapshots) erase the old spot.
void renderDucks() {
  for (int i = 0; i < kDucks; ++i) {
    Duck& d = ducks[i];
    if (!d.shown) continue;
    bool visible = duckVisible(i);
    if (visible && abs(d.x - d.shownX) <= kPad && abs(d.y - d.shownY) <= kPad) continue;
    gfx.fillRect(d.shownX - kPad, d.shownY - kPad, kBoxW, kBoxH, kBg);
    d.shown = false;
    for (int j = 0; j < kDucks; ++j) {
      if (j != i && ducks[j].shown && boxesOverlap(d.shownX, d.shownY, ducks[j].shownX, ducks[j].shownY)) {
        ducks[j].redraw = true;
      }
    }
  }
  for (int i = 0; i < kDucks; ++i) {
    Duck& d = ducks[i];
    if (!duckVisible(i)) continue;
    uint8_t frame = duckFrame(d);
    if (d.shown && !d.redraw && d.x == d.shownX && d.y == d.shownY && d.left == d.shownLeft &&
        frame == d.shownFrame) continue;
    gfx.blit(d.x - kPad, d.y - kPad, kBoxW, kBoxH, d.left ? duckLeft[frame] : duckRight[frame]);
    d.shownFrame = frame;
    d.shown = true;
    d.redraw = false;
    d.shownX = d.x;
    d.shownY = d.y;
    d.shownLeft = d.left;
  }
}

void markDuck(int i, uint16_t color, const char* label) {
  if (i < 0 || i >= kDucks) return;
  const Duck& d = ducks[i];
  if (!d.alive) {  // Show where a punched player fell.
    gfx.drawLine(d.x, d.y, d.x + kDuckW, d.y + kDuckH, color);
    gfx.drawLine(d.x + kDuckW, d.y, d.x, d.y + kDuckH, color);
  }
  for (int t = 0; t < 2; ++t) {
    gfx.drawRect(d.x - kPad - 2 - t, d.y - kPad - 2 - t, kBoxW + 4 + 2 * t, kBoxH + 4 + 2 * t, color);
  }
  gfx.setTextSize(1);
  gfx.setTextColor(color, kBg);
  int ly = d.y - kPad - 14;
  gfx.setCursor(d.x - 4, ly < kHudH + 1 ? d.y + kDuckH + kPad + 6 : ly);
  gfx.print(label);
}

void drawHudClock() {
  if (secondsLeft == shownSeconds || bannerUntil) return;
  shownSeconds = secondsLeft;
  char text[48];
  if (phase == kCountdown && mode == kSolo) {  // The hint is the only clue to the target.
    snprintf(text, sizeof(text), "%s  %d", kTraitHint[targetTrait], secondsLeft);
    hudBanner(kBlack, text);
    return;
  }
  if (phase == kCountdown) snprintf(text, sizeof(text), "READY %d", secondsLeft);
  else snprintf(text, sizeof(text), "%d:%02d", secondsLeft / 60, secondsLeft % 60);
  hudCenter(phase == kPlay && secondsLeft <= 10 ? kRed : kBlack, text);
}

// ---------------------------------------------------------------- world

bool blockedAt(int self, int x, int y, int count) {
  if (x < kPad || y < kHudH + kPad || x > kScreenW - kDuckW - kPad || y > kScreenH - kDuckH - kPad) return true;
  for (int j = 0; j < count; ++j) {
    if (j == self || !ducks[j].alive) continue;
    if (boxesOverlap(x, y, ducks[j].x, ducks[j].y)) return true;
  }
  return false;
}

int playerOfDuck(int i) {
  for (int p = 0; p < playerCount; ++p) if (players[p].duck == i) return p;
  return -1;
}

void pickNpcMove(Duck& d, bool isTarget) {
  int idle = 35, dash = 7, walkMin = 15, walkMax = 80;
  if (isTarget) {  // Small nudges only: the habit should take watching to spot.
    switch (targetTrait) {
      case kRunner: dash = 11; break;
      case kWalker: idle = 31; walkMin = 25; walkMax = 90; break;
      case kTurner: idle = 31; walkMin = 8; walkMax = 45; break;
      default: break;
    }
  }
  if (random(100) < idle) {
    d.dx = d.dy = 0;
    d.speed = 0;
    d.timer = random(10, 60);
    return;
  }
  do {
    d.dx = random(-1, 2);
    d.dy = random(-1, 2);
  } while (!d.dx && !d.dy);
  d.speed = random(100) < dash ? 2 : 1;  // NPCs dash too, so dashing is not a giveaway.
  d.timer = d.speed == 2 ? random(8, 25) : random(walkMin, walkMax);
}

void spawnDucks() {
  for (int i = 0; i < kDucks; ++i) {
    Duck& d = ducks[i];
    d = Duck{};
    for (int tries = 0; tries < 2000; ++tries) {
      d.x = random(kPad, kScreenW - kDuckW - kPad + 1);
      d.y = random(kHudH + kPad, kScreenH - kDuckH - kPad + 1);
      if (!blockedAt(i, d.x, d.y, i)) break;
    }
    d.alive = true;
    d.left = random(2);
    pickNpcMove(d, false);
    d.timer = random(0, 40);
  }
  // Players and the target are random ducks, so their index says nothing.
  int picks[3];
  for (int k = 0; k < 3; ++k) {
    bool repeat;
    do {
      picks[k] = random(kDucks);
      repeat = false;
      for (int m = 0; m < k; ++m) repeat |= picks[m] == picks[k];
    } while (repeat);
  }
  for (int p = 0; p < 2; ++p) players[p] = Player{picks[p], 0, kDashMax, false, p < playerCount};
  targetDuck = mode == kSolo ? picks[1] : -1;  // SOLO has one player; reuse the second pick.
  targetTrait = (Trait)random(kTraitCount);
  targetsHit = 0;
  punchesLeft = kScorePunches;
}

// SCORE: after a hit, a fresh target with a fresh habit.
void newTarget() {
  do { targetDuck = random(kDucks); } while (!ducks[targetDuck].alive || targetDuck == players[0].duck);
  targetTrait = (Trait)random(kTraitCount);
  char text[48];
  snprintf(text, sizeof(text), "NEW %s", kTraitHint[targetTrait]);
  hudBanner(kBlack, text);
  bannerUntil = tickCount + kNewTargetHintSeconds * kTps;
}

bool tryStep(int i, int sx, int sy) {
  Duck& d = ducks[i];
  if (blockedAt(i, d.x + sx, d.y + sy, kDucks)) return false;
  d.x += sx;
  d.y += sy;
  ++d.steps;
  return true;
}

// Every duck, player or not, animates the same way: feet move while walking.
uint8_t duckFrame(const Duck& d) { return (d.steps / kStepPixels) & 1; }

// Moves up to `speed` pixels, sliding along obstacles. Returns false if stuck.
bool moveDuck(int i, int dx, int dy, int speed) {
  Duck& d = ducks[i];
  if (dx) d.left = dx < 0;
  for (int s = 0; s < speed; ++s) {
    if (tryStep(i, dx, dy)) continue;
    if (dx && dy && tryStep(i, dx, 0)) continue;
    if (dx && dy && tryStep(i, 0, dy)) continue;
    return false;
  }
  return true;
}

void updateNpcs() {
  for (int i = 0; i < kDucks; ++i) {
    Duck& d = ducks[i];
    if (!d.alive || playerOfDuck(i) >= 0) continue;
    if (d.timer == 0) pickNpcMove(d, i == targetDuck);
    else --d.timer;
    if (d.speed && !moveDuck(i, d.dx, d.dy, d.speed)) d.timer = 0;
  }
}

void movePlayer(int p, const Command& c) {
  Player& pl = players[p];
  if (!pl.alive) return;
  if (pl.cooldown) --pl.cooldown;
  bool moving = c.dx || c.dy;
  bool dash = c.dash && moving && (pl.dashing ? pl.dash > 0 : pl.dash >= kDashMin);
  pl.dashing = dash;
  if (dash) --pl.dash;
  else if (pl.dash < kDashMax && (tickCount & 1)) ++pl.dash;
  if (moving) moveDuck(pl.duck, c.dx, c.dy, dash ? 2 : 1);
}

// Knocks out the duck nearest to `from`, if one is in reach. Returns it or -1.
int punchFrom(int from, int spare = -1) {
  const Duck& me = ducks[from];
  int best = -1, bestDist = kPunchReach * kPunchReach + 1;
  for (int j = 0; j < kDucks; ++j) {
    if (j == from || j == spare || !ducks[j].alive) continue;
    int ex = ducks[j].x - me.x, ey = ducks[j].y - me.y;
    int dist = ex * ex + ey * ey;
    if (dist < bestDist) { bestDist = dist; best = j; }
  }
  if (best >= 0) ducks[best].alive = false;  // Gone at once, no effect drawn.
  return best;
}

constexpr int kNoPunch = -2;

// Returns the duck knocked out, -1 for a miss, or kNoPunch while cooling down.
int punch(int p) {
  Player& pl = players[p];
  if (!pl.alive || pl.cooldown) return kNoPunch;
  pl.cooldown = kCooldownTicks;
  return punchFrom(pl.duck);
}

// ---------------------------------------------------------------- phases

// Freeze message in the HUD; the normal bar comes back when play resumes.
void showPause(Pause why) {
  if (why == pauseReason) return;
  pauseReason = why;
  if (why == kPausedHere) hudBanner(kRed, "RECONNECT CONTROLS - paused");
  else if (why == kPausedThere) hudBanner(kRed, "OTHER PLAYER: RECONNECT CONTROLS");
  else { bannerUntil = 0; drawHudBar(); }
}

void enterTitle() {
  phase = kTitle;
  mode = kNone;
  result = kNoResult;
  phaseTick = tickCount;
  drawTitle();
}

void enterWait() {
  phase = kWait;
  mode = kNone;
  phaseTick = tickCount;
  drawWait();
}

void enterCountdown() {
  // The console is held in its playing position when the round starts.
  for (int k = 0; k < 3; ++k) tiltZero[k] = in.a[k];
  phase = kCountdown;
  phaseTick = tickCount;
  result = kNoResult;
  pauseReason = kNotPaused;
  remoteControlsOk = true;
  secondsLeft = countdownSeconds();
  if (mode != kClient) spawnDucks();
  else for (auto& d : ducks) d.alive = false;  // Wait for the host's first snapshot.
  drawArena();
  renderDucks();
}

void enterPlay() {
  phase = kPlay;
  phaseTick = tickCount;
  playTicks = 0;
  secondsLeft = kRoundSeconds;
  drawHudBar();  // Replace the countdown hint with the normal bar.
}

int localPlayer() { return mode == kClient ? 1 : 0; }

void drawResult() {
  bool won = result == (localPlayer() == 0 ? kP1Wins : kP2Wins);
  if (mode == kSolo) {
    char text[48];
    if (soloKind == kHunt) {
      if (result == kP1Wins) snprintf(text, sizeof(text), "GOT IT! YOU WIN");
      else if (result == kTargetGotYou) snprintf(text, sizeof(text), "THE TARGET GOT YOU - YOU LOSE");
      else if (result == kDuckGotYou) snprintf(text, sizeof(text), "A DUCK GOT YOU - YOU LOSE");
      else snprintf(text, sizeof(text), "TIME UP - YOU LOSE");
    } else {
      if (result == kP1Wins) snprintf(text, sizeof(text), "%d/%d TARGETS! YOU WIN", kScoreTargets, kScoreTargets);
      else if (result == kOutOfPunches) snprintf(text, sizeof(text), "OUT OF PUNCHES - %d/%d", targetsHit, kScoreTargets);
      else if (result == kTargetGotYou) snprintf(text, sizeof(text), "THE TARGET GOT YOU - %d/%d", targetsHit, kScoreTargets);
      else if (result == kDuckGotYou) snprintf(text, sizeof(text), "A DUCK GOT YOU - %d/%d", targetsHit, kScoreTargets);
      else snprintf(text, sizeof(text), "TIME UP - %d/%d", targetsHit, kScoreTargets);
    }
    hudBanner(result == kP1Wins ? kGreen : kRed, text);
    markDuck(targetDuck, kRed, "TARGET");
    markDuck(players[0].duck, kBlue, "YOU");
    return;
  }
  if (result == kTimeUp) hudBanner(kRed, "TIME UP - EVERYONE LOSES");
  else if (result == kLinkLost) hudBanner(kRed, "CONNECTION LOST");
  else hudBanner(won ? kGreen : kRed, won ? "YOU WIN! - any button" : "YOU LOSE - any button");
  if (result != kLinkLost) {
    markDuck(players[localPlayer()].duck, kBlue, "YOU");
    markDuck(players[1 - localPlayer()].duck, kRed, "RIVAL");
  }
}

void enterOver(Result r) {
  result = r;
  phase = kOver;
  phaseTick = tickCount;
  renderDucks();
  drawResult();
}

// A duck was just knocked out by another duck. If it was a player, that
// player is out. Returns true if that ended a solo round.
bool duckKnockedOut(int victim, Result soloLoss) {
  int p = playerOfDuck(victim);
  if (p < 0) return false;
  players[p].alive = false;
  if (mode != kSolo) return false;  // HOST checks both players below.
  renderDucks();
  enterOver(soloLoss);
  return true;
}

// SOLO and HOST: advance the world one tick.
void simulate(const Command& mine) {
  bool canPunch = phase == kPlay;
  Command other = remote;
  if (!canPunch) other.punch = false;
  Command me = mine;
  if (!canPunch) me.punch = false;
  movePlayer(0, me);
  if (mode == kHost) movePlayer(1, other);
  remote.punch = false;
  updateNpcs();

  // Ordinary ducks punch too. They never knock out a solo target, or the
  // round could not be won.
  if (canPunch && random(kNpcPunchSeconds * kTps) == 0) {
    int puncher = random(kDucks);
    if (ducks[puncher].alive && playerOfDuck(puncher) < 0 && puncher != targetDuck) {
      int victim = punchFrom(puncher, mode == kSolo ? targetDuck : -1);
      if (victim >= 0 && duckKnockedOut(victim, kDuckGotYou)) return;
    }
  }
  // A fighter target knocks out neighbours more often - maybe you.
  if (mode == kSolo && targetTrait == kFighter && canPunch && ducks[targetDuck].alive &&
      tickCount % kTps == 0 && random(100) < kFighterChance) {
    int victim = punchFrom(targetDuck);
    if (victim >= 0 && duckKnockedOut(victim, kTargetGotYou)) return;
  }

  int hit0 = me.punch ? punch(0) : kNoPunch;
  int hit1 = (mode == kHost && other.punch) ? punch(1) : kNoPunch;
  if (mode == kSolo && hit0 != kNoPunch) {
    if (soloKind == kScore) --punchesLeft;
    if (hit0 == targetDuck) {
      if (soloKind == kHunt || ++targetsHit >= kScoreTargets) {
        renderDucks();
        enterOver(kP1Wins);
        return;
      }
      newTarget();
    } else if (soloKind == kScore && punchesLeft <= 0) {
      renderDucks();
      enterOver(kOutOfPunches);
      return;
    }
    drawHudScore();
  }
  if (mode == kHost) {
    if (hit0 == players[1].duck) players[1].alive = false;
    if (hit1 == players[0].duck) players[0].alive = false;
    if (!players[0].alive || !players[1].alive) {
      renderDucks();
      // Both punched each other in the same tick: nobody is left standing.
      enterOver(players[0].alive ? kP1Wins : players[1].alive ? kP2Wins : kTimeUp);
      return;
    }
  }
  renderDucks();
}

void tickGame(const Command& mine) {
  if (phase == kCountdown) {
    secondsLeft = countdownSeconds() - (int)(tickCount - phaseTick) / kTps;
    drawHudClock();
    simulate(mine);
    if (tickCount - phaseTick >= (uint32_t)(countdownSeconds() * kTps)) enterPlay();
    return;
  }
  ++playTicks;
  secondsLeft = kRoundSeconds - (int)(playTicks / kTps);
  if (bannerUntil && tickCount >= bannerUntil) {
    bannerUntil = 0;
    drawHudBar();
  }
  drawHudClock();
  simulate(mine);
  if (phase == kPlay && secondsLeft <= 0) enterOver(kTimeUp);
}

void tick() {
  readInputs();
  uint8_t pressed = in.held & ~prevHeld;
  prevHeld = in.held;

  switch (phase) {
    case kTitle:
      animateParade();
      drawTitleControls();
      setLeds(true, true, true);
      if (!controlsReady()) break;
      if (pressed & (kA | kB)) {
        mode = kSolo;
        soloKind = (pressed & kA) ? kHunt : kScore;
        playerCount = 1;
        enterCountdown();
      } else if (pressed & kC) {
        enterWait();
      } else if (pressed & kStick) {
        enterTiltSetup();
      }
      break;

    case kTiltSetup:
      setLeds(true, false, true);
      tiltSetupTick(pressed);
      break;

    case kWait:  // Python finds the other console and calls ducks_match().
      setLeds(true, false, false);
      if (pressed & (kA | kC)) enterTitle();
      break;

    case kCountdown:
    case kPlay:
      if (pressed & kC) {  // Leave the round. Online, Python then drops the link.
        enterTitle();
        break;
      }
      setLeds(false, false, true);
      if (mode == kClient) {
        latchedPresses |= pressed;
        if (millis() - lastSnapshotAt > 4000) enterOver(kLinkLost);
        break;
      }
      {
        Pause why = !controlsReady() ? kPausedHere
                  : (mode == kHost && !remoteControlsOk) ? kPausedThere
                  : kNotPaused;
        showPause(why);
        if (why != kNotPaused) {
          ++phaseTick;  // Freeze the countdown too; play time uses playTicks.
          remote.punch = false;
          setLeds(false, false, false);
          break;
        }
      }
      tickGame(localCommand(pressed));
      break;

    case kOver: {
      bool blink = (tickCount / 8) & 1;
      setLeds(blink, false, false);
      if (tickCount - phaseTick > (uint32_t)kTps && (pressed & (kA | kB | kC))) enterTitle();
      break;
    }
  }
}

// ---------------------------------------------------------------- network

// Snapshot: 8-byte header, then 4 bytes per duck.
//   header: phase, seconds lo, seconds hi, result, p1 duck, p2 duck,
//           pause (1 = host's controls missing, 2 = client's), 0
//   duck:   x lo, x hi, y lo, y hi | 0x10 left | 0x20 alive
// Player ducks are only filled in once the round is over.
constexpr int kSnapshotSize = 8 + 4 * kDucks;

String hostSnapshot() {
  static const char hex[] = "0123456789abcdef";
  uint8_t bytes[kSnapshotSize];
  bool over = phase == kOver;
  bytes[0] = phase;
  bytes[1] = secondsLeft & 0xFF;
  bytes[2] = (secondsLeft >> 8) & 0xFF;
  bytes[3] = result;
  bytes[4] = over ? players[0].duck : 0xFF;
  bytes[5] = over ? players[1].duck : 0xFF;
  bytes[6] = pauseReason;
  bytes[7] = 0;
  for (int i = 0; i < kDucks; ++i) {
    const Duck& d = ducks[i];
    uint8_t* p = bytes + 8 + 4 * i;
    p[0] = d.x & 0xFF;
    p[1] = (d.x >> 8) & 0xFF;
    p[2] = d.y & 0xFF;
    p[3] = ((d.y >> 8) & 0x0F) | (d.left ? 0x10 : 0) | (d.alive ? 0x20 : 0);
  }
  String out;
  out.reserve(2 * kSnapshotSize);
  for (uint8_t b : bytes) { out += hex[b >> 4]; out += hex[b & 15]; }
  return out;
}

// HOST: Python passes the client's latest input and gets the world back.
String ducksHost(int held, int presses, int dx, int dy, int linkOk, int remoteOk) {
  remoteControlsOk = remoteOk;
  if (mode != kHost) return String("");
  remote.dx = constrain(dx, -1, 1);
  remote.dy = constrain(dy, -1, 1);
  remote.dash = held & kB;
  remote.punch = remote.punch || (presses & kA);
  if (!linkOk && (phase == kCountdown || phase == kPlay)) enterOver(kLinkLost);
  return hostSnapshot();
}

// CLIENT: Python passes the host's latest snapshot (or nothing) and gets this
// console's input back as "held,presses,dx,dy,controls_ok".
String ducksClient(MsgPack::bin_t<uint8_t> snap, int linkOk) {
  if (mode != kClient) return String("");
  if (!linkOk && (phase == kCountdown || phase == kPlay)) enterOver(kLinkLost);
  if (snap.size() == kSnapshotSize && phase != kOver) {
    const uint8_t* b = snap.data();
    lastSnapshotAt = millis();
    for (int i = 0; i < kDucks; ++i) {
      const uint8_t* p = b + 8 + 4 * i;
      Duck& d = ducks[i];
      int nx = constrain(p[0] | (p[1] << 8), 0, kScreenW - 1);
      int ny = constrain(p[2] | ((p[3] & 0x0F) << 8), 0, kScreenH - 1);
      d.steps += max(abs(nx - d.x), abs(ny - d.y));  // Animate feet like the host does.
      d.x = nx;
      d.y = ny;
      d.left = p[3] & 0x10;
      d.alive = p[3] & 0x20;
    }
    secondsLeft = b[1] | (b[2] << 8);
    Phase hostPhase = (Phase)b[0];
    if (hostPhase == kPlay && phase == kCountdown) enterPlay();
    if (hostPhase == kCountdown || hostPhase == kPlay) {
      // The host's pause byte is from its own view: 1 = host, 2 = us.
      Pause hostPause = b[6] == 1 ? kPausedThere : b[6] == 2 ? kPausedHere : kNotPaused;
      showPause(hostPause);
      drawHudClock();
      renderDucks();
    } else if (hostPhase == kOver) {
      players[0].duck = b[4] < kDucks ? b[4] : -1;
      players[1].duck = b[5] < kDucks ? b[5] : -1;
      Result r = b[3] <= kLinkLost ? (Result)b[3] : kLinkLost;
      enterOver(r);
    }
  }
  Command c = localCommand(latchedPresses);
  char out[32];
  snprintf(out, sizeof(out), "%d,%d,%d,%d,%d", in.held, latchedPresses, c.dx, c.dy, controlsReady() ? 1 : 0);
  latchedPresses = 0;
  return String(out);
}

// Python found the other console. role 1 = host, 2 = client.
bool ducksMatch(int role) {
  if (phase != kWait) return false;
  mode = role == 1 ? kHost : kClient;
  playerCount = 2;
  remote = Command{};
  lastSnapshotAt = millis();
  enterCountdown();
  return true;
}

// Python keeps the TILT SETUP result in data/tilt.json across restarts.
String ducksGetTilt() {
  char out[96];
  snprintf(out, sizeof(out), "%d,%d,%d,%d,%d,%d,%d", tiltRight[0], tiltRight[1], tiltRight[2],
           tiltForward[0], tiltForward[1], tiltForward[2], tiltThreshold);
  return String(out);
}

bool ducksSetTilt(int rx, int ry, int rz, int fx, int fy, int fz, int threshold) {
  const int values[] = {rx, ry, rz, fx, fy, fz};
  for (int v : values) if (v < -1000 || v > 1000) return false;
  if (threshold < 50 || threshold > 1000) return false;
  tiltRight[0] = rx; tiltRight[1] = ry; tiltRight[2] = rz;
  tiltForward[0] = fx; tiltForward[1] = fy; tiltForward[2] = fz;
  tiltThreshold = threshold;
  return true;
}

// Test hook: behave as if the Buttons module were unplugged for a few
// seconds, through the same failure path a real unplug takes.
bool ducksTestDrop(int seconds) {
  testDropUntil = millis() + (uint32_t)constrain(seconds, 0, 30) * 1000;
  return true;
}

const char* setupStep = "starting";
bool setupDone = false;

String ducksStatus() {
  if (!setupDone) return String("phase=SETUP step=") + setupStep;
  static const char* const phases[] = {"TITLE", "WAIT", "COUNTDOWN", "PLAY", "OVER", "TILT"};
  static const char* const modes[] = {"NONE", "SOLO", "HOST", "CLIENT"};
  int tx, ty;
  tiltVector(tx, ty);
  snprintf(statusLine, sizeof(statusLine),
           "phase=%s mode=%s left=%d result=%d ctl=%c%c%c stick=%d,%d tilt=%d,%d accel=%d,%d,%d "
           "cal=%d worst_tick_ms=%lu",
           phases[phase], modes[mode], secondsLeft, result == kNoResult ? -1 : (int)result,
           in.buttonsOk ? 'B' : '-', in.stickOk ? 'S' : '-', in.imuOk ? 'T' : '-', in.sx, in.sy, tx, ty,
           in.a[0], in.a[1], in.a[2], calVersion, (unsigned long)worstTickMs);
  worstTickMs = 0;
  return String(statusLine);
}

// ---------------------------------------------------------------- main

// Bridge comes up first so `make logs` shows which setup step is running if
// the console ever hangs during start-up.
void step(const char* name) {
  setupStep = name;
  Monitor.println(name);
}

void setup() {
  if (Bridge.begin()) {
    // Not provide_safe: status must answer even while setup() is running.
    Bridge.provide("ducks_status", ducksStatus);
    Bridge.provide_safe("ducks_match", ducksMatch);
    Bridge.provide_safe("ducks_host", ducksHost);
    Bridge.provide_safe("ducks_client", ducksClient);
    Bridge.provide_safe("ducks_get_tilt", ducksGetTilt);
    Bridge.provide_safe("ducks_set_tilt", ducksSetTilt);
    Bridge.provide_safe("ducks_test_drop", ducksTestDrop);
    Monitor.begin();
  }
  step("modulino");
  Modulino.begin(Wire1);
  buttons.begin();
  movementReady = movement.begin();
  step("display");
  display.begin();
  display.setRotation(1);  // Landscape: 480 x 320.
  gfx.begin();
  step("sprites");
  for (int frame = 0; frame < 2; ++frame) {
    buildSprite(kDuckArt, false, frame, duckRight[frame]);
    buildSprite(kDuckArt, true, frame, duckLeft[frame]);
  }
  randomSeed(micros() ^ (analogRead(A5) << 16));
  step("inputs");
  for (int i = 0; i < 4; ++i) readInputs();
  step("title");
  enterTitle();
  step("running");
  setupDone = true;
  nextTickAt = millis();
}

void loop() {
  uint32_t now = millis();
  if ((int32_t)(now - nextTickAt) < 0) {
    delay(1);
    return;
  }
  nextTickAt += kTickMs;
  if ((int32_t)(now - nextTickAt) > 200) nextTickAt = now + kTickMs;  // Don't race to catch up.
  ++tickCount;
  tick();
  uint32_t spent = millis() - now;
  if (spent > worstTickMs) worstTickMs = spent;
}

#pragma once
// 16x14 pixel art, facing right. Each sprite is stored with a 2-pixel
// background-coloured border so drawing a duck at its new position also erases its last position.

#include <Arduino.h>

constexpr int kDuckW = 16;
constexpr int kDuckH = 14;
constexpr int kPad = 2;
constexpr int kBoxW = kDuckW + 2 * kPad;
constexpr int kBoxH = kDuckH + 2 * kPad;

constexpr uint16_t kWhite = 0xFFFF;
constexpr uint16_t kGrass = 0x7DEB;  // Arena background; set to kWhite for a plain board.
constexpr uint16_t kBg = kGrass;
constexpr uint16_t kBlack = 0x0000;
constexpr uint16_t kYellow = 0xFEA0;
constexpr uint16_t kWing = 0xE4C0;
constexpr uint16_t kOrange = 0xFC00;
constexpr uint16_t kGray = 0xAD55;
constexpr uint16_t kRed = 0xF800;
constexpr uint16_t kBlue = 0x041F;
constexpr uint16_t kGreen = 0x0560;

// . background  y body  w wing  o beak/feet  k eye  g smoke
const char* const kDuckArt[kDuckH] = {
    "..........yyyy..",
    ".........yyyyyy.",
    ".........yyykyoo",
    ".........yyyyyoo",
    "..........yyyy..",
    "y.........yyy...",
    "yy.....yyyyyyy..",
    "yyyyyyyyyyyyyyy.",
    "yyyywwwwwyyyyyy.",
    ".yyyywwwwyyyyyy.",
    "..yyyyyyyyyyyy..",
    "...yyyyyyyyyy...",
    ".....o....o.....",
    "....oo...oo.....",
};

#if 0  // Unused: kills now vanish without a trace.
const char* const kPoofArt[kDuckH] = {
    "................",
    ".....gggg.......",
    "...gggggggg.....",
    "..gggg..gggggg..",
    ".gggggggggggggg.",
    ".ggg.gggggg.ggg.",
    "gggggggggggggggg",
    ".gggggg..ggggggg",
    "..ggggggggggggg.",
    "...gggg.gggggg..",
    ".....gggggg.....",
    "................",
    "................",
    "................",
};
#endif

// Second walking frame: the feet step apart. Replaces the last two art rows.
const char* const kFeetStep[2] = {
    "......o..o......",
    ".....oo..oo.....",
};

inline uint16_t artColor(char c) {
  switch (c) {
    case 'y': return kYellow;
    case 'w': return kWing;
    case 'o': return kOrange;
    case 'k': return kBlack;
    case 'g': return kGray;
    default: return kBg;
  }
}

// Expand art into a kBoxW x kBoxH RGB565 image, optionally mirrored, with
// either the standing feet or the stepping feet.
inline void buildSprite(const char* const* art, bool mirror, bool stepping, uint16_t* out) {
  for (int i = 0; i < kBoxW * kBoxH; ++i) out[i] = kBg;
  for (int y = 0; y < kDuckH; ++y) {
    const char* row = (stepping && y >= kDuckH - 2) ? kFeetStep[y - (kDuckH - 2)] : art[y];
    for (int x = 0; x < kDuckW; ++x) {
      int src = mirror ? kDuckW - 1 - x : x;
      out[(y + kPad) * kBoxW + x + kPad] = artColor(row[src]);
    }
  }
}

# Duck Duck Punch

40 identical ducks on the grass. One of them is you, but nothing on screen tells you which one. Move around, work out which duck you are, then find your target and punch it before someone punches you.

Built for the **Arcade** track of *Build with Arduino UNO Q: Hackout Edition*. It runs on the preassembled UNO Q console with a DIYables 3.5" TFT and Modulino Joystick, Buttons and Movement.

## How to play

> **First time on a console?** Press the joystick down (click it) on the title screen to open **TILT SETUP** and calibrate tilt steering. It takes about 10 seconds and is saved on the board. See [TILT SETUP](#tilt-setup).

### Modes

Pick a mode on the title screen:

| Button | Mode | Goal | You lose if |
| --- | --- | --- | --- |
| **A** | **HUNT** (solo) | One target duck. You get only a hint about its habit. Find it and punch it. | Time runs out, or a duck punches you |
| **B** | **SCORE** (solo) | Three targets in a row, with only **15 punches** for the whole round | You run out of punches, time runs out, or a duck punches you |
| **C** | **ONLINE** (2 consoles) | Find the other player and punch them. The last duck standing wins. | You get punched, or time runs out (then **both** players lose) |

Every round lasts **3 minutes**.

### Controls

| Control | Action |
| --- | --- |
| Joystick | Move. 8 directions; the stick takes priority when it is pushed. |
| Tilt the console | Move, when the stick is centred. The neutral position is recorded when the round starts. Run **TILT SETUP** once per console (see [Calibration](#calibration)). |
| **B** (hold) | Dash. About 1 second of stamina, which recharges. |
| **A** | Punch. Knocks out the nearest duck within reach. |
| **C** | Leave the round and go back to the title screen. Online, the other console sees **CONNECTION LOST**. |
| Stick click (title screen) | Open **TILT SETUP** |
| Any button | Back to the title screen after a round |

### Rules that make it a game

- **You are never highlighted.** No rings, flashes or markers show your own duck. The only way to find yourself is to move and watch which duck answers to your input.
- **Punches leave no trace.** The duck you hit simply disappears.
- **Ordinary ducks punch too.** About every 10 seconds, a random duck knocks out its nearest neighbour, and that neighbour can be you. So a duck vanishing next to someone proves nothing. Ducks that get knocked out do not come back.
- **NPC ducks walk, stop, turn and sometimes dash**, so a player who dashes does not stand out by dashing alone. Every duck's feet step while it walks, players included, so the animation gives nothing away.
- **Solo targets have a habit.** The full hint is shown during a 6-second countdown (5 seconds for each new SCORE target) and then stays on the HUD as a short tag. Each habit only nudges the target's odds by a few percent compared with an ordinary duck:

  | HUD tag | Hint | What the target does differently |
  | --- | --- | --- |
  | RUNNER | "TARGET loves to run" | Dash chance 11% instead of 7% |
  | WALKER | "TARGET never stops walking" | Stops less often and walks for longer |
  | TURNER | "TARGET can't walk straight" | Short walks, so it changes direction often |
  | FIGHTER | "TARGET picks fights. Careful!" | Punches a neighbour 8% of the time each second. It can knock *you* out. |

  Ordinary ducks never knock out a solo target, so every round can still be won.
- **The answer comes at the end.** When the round ends, a blue box marks **YOU**, and a red box marks the **TARGET** or **RIVAL**.

### HUD

| Left | Centre | Right |
| --- | --- | --- |
| The target's habit tag (solo) or `ONLINE` | Time left (red during the last 10 s) | SCORE mode: targets hit and punches left, e.g. `1/3 P12` |

On the title screen, the A/B/C button LEDs are lit. During a round, the C LED stays on as the exit button. During ONLINE matchmaking, C cancels.

## Run it

This is an Arduino App Lab app: a Python program for the MPU (`python/`) plus an Arduino sketch for the MCU (`sketch/`).

### From a terminal (macOS/Linux)

You need GNU Make and `zip`. `adb` is taken from your `PATH`, or else from the copy that App Lab installs (`~/Library/Arduino15/packages/arduino/tools/adb/*/adb`).

```sh
cd ducks
make flash   # package, copy to the board, compile, upload and start
make logs    # follow the Python log (status line every second)
make stop    # stop the game
```

The first build downloads the Zephyr core and libraries and takes 10–15 minutes on the board. Later builds are incremental. Only one App Lab app can run at a time. Stop any other app first, in App Lab or as shown in the [arcade guide](../arcade/README.md#terminal-commands).

### From App Lab

Run `make package`, then import `zip/uno-q-ducks.zip` from **My Apps** in App Lab and run it.

### Board software: use Zephyr core 1.0.0

`sketch/sketch.yaml` pins `arduino:zephyr (1.0.0)`, with `Arduino_RouterBridge 0.4.3` and `Arduino_RPClite 0.3.1`. On our console the MCU loader had already been updated to 1.0.0. A sketch built with the starter's 0.55.2 core uploaded without errors but never ran: the screen stayed white, and Python reported `method ... not available`. If you see that symptom, check that the core version matches the board.

## Online play

1. Connect both consoles to the **same phone hotspot**. Campus or guest Wi-Fi such as eduroam or NUwave usually blocks device-to-device traffic, or needs a browser login that the board cannot complete.
2. Run the game on both consoles and press **C** on both title screens.
3. The consoles find each other automatically. The console with the lower IP address becomes the **host**: its MCU runs the world. The other console is the **client**: it sends its player's input and draws the snapshots it receives.

How it works:

- Each console listens on TCP port **47800**. This port is published to the app's container through `ports:` in `app.yaml`.
- Each console scans its `/24` subnet for the other one.
- The host sends a 168-byte world snapshot about 20 times a second (the relay loop runs every 45 ms); the client sends back its input. Button presses are latched, so a quick tap is not lost between messages.
- If a link stays silent for 3 seconds, the client shows **CONNECTION LOST**.

To force a role while testing, create `data/net.json` in the app folder on the board. `make flash` keeps `data/` between deploys.

```json
{"role": "host"}
```

```json
{"role": "client", "peer": "172.20.10.3:47800"}
```

> **Status:** both solo modes, TILT SETUP and the title screen have been played and checked on the console. Pausing on lost controls was tested with the `ducks_test_drop` hook (see below): during a 6-second simulated loss of the Buttons module, the clock held at 2:52 and then carried on from there. Online play has not been verified on two physical consoles yet.

## Calibration

| Setting | Where | Default | Notes |
| --- | --- | --- | --- |
| Display controller | `ARCADE_TFT_HX8357D` in `sketch.ino` | `1` (HX8357D) | Set `0` for RM68140 |
| Tilt directions and sensitivity | **TILT SETUP** screen | right = +X, forward = −Y, 170 mg | Run once per console. Saved on the board in `data/tilt.json`. The app ships with **our console's** `data/tilt.json` (see below). |
| Tilt neutral | automatic | — | Recorded when a round starts. Hold the console in its playing position when you press the start button. |
| Stick dead zone | `kStickThreshold` | `45` | Raw stick units, range -127..128 |
| Fast display bus | `DUCKS_FAST_BUS` in `screen.h` | `1` | Set `0` to use the library's slower drawing if the screen shows garbage |

### TILT SETUP

On the title screen, press the joystick down (click it). The title screen does not show this shortcut. The console then guides you through three steps; hold each pose and press **A**:

1. Hold the console the way you play.
2. Tilt it to the **right**.
3. Tilt the **top away** from you.

A red dot then follows your tilt. Once it leaves the grey inner box, a duck would start walking. Press **A** to redo the setup or **C** to finish.

How it works:

- All three accelerometer axes are used, so it works however the Movement module is mounted and however the console is held, upright or flat.
- The right and forward directions you record rarely meet at exactly 90°. The tilt is split into those two directions with a 2×2 solve, so tilting forward never steers sideways.
- Walking starts at 40% of the tilt you showed during setup, clamped to 100–400 mg. Gentle tilts during setup give gentle steering in the game.
- The setup rejects tilts under 150 mg, and a "forward" tilt that is really sideways.
- The result is saved on the board in `data/tilt.json` and restored on start-up. `make flash` keeps `data/`. Each console keeps its own calibration, so online partners can hold their consoles differently.

**The bundled `data/tilt.json` is the calibration from our own console**, recorded with TILT SETUP and held upright the way we play. It is loaded automatically, so our console steers correctly straight after import. On any other console, or if you hold it differently, run TILT SETUP once: the new result replaces this file. If you delete the file, the game falls back to the default mapping (right = +X, forward = −Y, 170 mg).

## Tuning

All of these are `constexpr` values near the top of `sketch/sketch.ino`:

| Constant | Default | Meaning |
| --- | --- | --- |
| `kDucks` | 40 | Ducks on the field, players included |
| `kRoundSeconds` | 180 | Round length in seconds |
| `kPunchReach` | 28 px | Maximum centre-to-centre distance for a punch to land |
| `kCooldownTicks` | 15 | Minimum time between punches (half a second) |
| `kScoreTargets` / `kScorePunches` | 3 / 15 | SCORE mode goal and punch budget |
| `kNpcPunchSeconds` | 10 | On average, an ordinary duck punches this often |
| `kFighterChance` | 8 | Chance per second, in %, that a FIGHTER target punches a neighbour |
| `kDashMax` / `kDashMin` | 30 / 8 | Dash stamina in ticks, and the minimum stamina needed to start a dash |

## How it works

```mermaid
flowchart LR
    subgraph console1["Console (host)"]
      mcu1["MCU sketch<br/>controls, world, drawing"] <-->|Bridge| py1["Python<br/>matchmaking, relay"]
    end
    subgraph console2["Console (client)"]
      py2["Python<br/>matchmaking, relay"] <-->|Bridge| mcu2["MCU sketch<br/>controls, drawing"]
    end
    py1 <-->|"TCP 47800: snapshots / input"| py2
```

- **The game runs on the MCU at 30 ticks per second.** It reads the Modulinos over `Wire1`, moves the ducks and draws them. In solo play, Python only logs and keeps the tilt calibration file.
- **Fast drawing.** The DIYables library drives the 8-bit parallel bus with about 20 `digitalWrite()` calls per pixel on UNO Q, which is too slow for 40 moving sprites. After the library has set up the panel, `screen.h` writes the same bus through the STM32 GPIO set/reset registers instead. A whole tick, 40 ducks included, takes under 10 ms.
- **No full-screen redraws.** Each sprite carries a 2-pixel border in the grass colour, so drawing a duck at its new position also erases its trail. Ducks are never allowed to overlap.
- **Calibrated tilt.** TILT SETUP stores the right and forward directions as 3-D unit vectors. Each tick, the change in acceleration since the round started is split into those two directions.
- **Robust inputs.** A single failed I2C read keeps the last value. Only repeated failures mark a control as missing, and the title screen shows each control's status.
- **Lost controls pause the round.** The round freezes, countdown and clock included, if a console loses its Buttons module or has neither stick nor tilt. The HUD shows **RECONNECT CONTROLS - paused**; online, the other console shows **OTHER PLAYER: RECONNECT CONTROLS**. Play resumes by itself once the module answers again. Losing only the stick or only tilt does not pause the round, because the other one still steers.

  To test this without pulling a Qwiic cable, call the `ducks_test_drop` Bridge method. It makes the sketch treat the Buttons module as unplugged for the given number of seconds (30 at most), through the same failure path a real unplug takes:

  ```sh
  adb shell 'docker exec uno-q-ducks-cli-main-1 sh -c "cd /app/python && /app/.cache/.venv/bin/python -c \"from arduino.app_utils import Bridge; Bridge.call(\\\"ducks_test_drop\\\", 6)\""'
  ```

## Files

| File | Role |
| --- | --- |
| `sketch/sketch.ino` | Game rules, ducks, modes, HUD, and the Bridge methods for online play |
| `sketch/screen.h` | Fast TFT drawing on top of the DIYables driver |
| `sketch/sprites.h` | Duck pixel art and colours |
| `sketch/sketch.yaml` | Pinned Zephyr core and libraries |
| `python/main.py` | Online matchmaking and the snapshot/input relay; saving and restoring the tilt calibration; status log |
| `app.yaml` | App Lab app definition and submission details (publishes port 47800) |
| `data/tilt.json` | Tilt calibration from **our** console; replaced when you run TILT SETUP |
| `Makefile`, `scripts/flash.sh` | Terminal build and deploy, adapted from the arcade starter |

## Credits

- Starter structure, Modulino input code and the deploy scripts come from the hackathon's [arcade starter](../arcade/).
- Display driver: [DIYables TFT Touch Shield](https://github.com/DIYables/DIYables_TFT_Touch_Shield) library, with Adafruit GFX for text.
- Duck pixel art, game design and code: our team. No third-party assets.

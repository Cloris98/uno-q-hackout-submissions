"""Duck Duck Punch, MPU side: online matchmaking and relay.

The game itself runs on the MCU. For ONLINE play this program:
  1. listens on TCP PORT and scans the hotspot's subnet for the other console;
  2. the console with the lower IP address becomes the host;
  3. the host MCU simulates the world. Each cycle the host sends a snapshot
     to the client, and the client sends back its player's input.

Both consoles must be on the same Wi-Fi (a phone hotspot works; campus Wi-Fi
usually blocks device-to-device traffic). For testing, data/net.json can force
a role: {"role": "host"} or {"role": "client", "peer": "IP:PORT"}.
"""

import ipaddress
import json
import os
import socket
import struct
import threading
import time
from concurrent.futures import ThreadPoolExecutor

from arduino.app_utils import App, Bridge

PORT = 47800
CYCLE_S = 0.045        # Relay cadence, about 22 updates per second.
LINK_TIMEOUT_S = 3.0   # Silence after which the other console is gone.
DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data")
CONFIG = os.path.join(DATA_DIR, "net.json")
TILT_FILE = os.path.join(DATA_DIR, "tilt.json")  # Written after TILT SETUP.
MY_IP = os.environ.get("HOST_IP", "")


def ip_key(ip):
    return tuple(int(part) for part in ip.split("."))


def load_config():
    try:
        with open(CONFIG) as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return {}


class Link:
    """One TCP connection carrying length-prefixed frames: 1 type byte + body."""

    def __init__(self, sock):
        self.sock = sock
        self.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        self.lock = threading.Lock()
        self.last_rx = time.monotonic()
        self.closed = False
        self.latest = {}       # Latest body per frame type.
        self.presses = 0       # Client presses OR-ed until the host uses them.
        threading.Thread(target=self._reader, daemon=True).start()

    def send(self, kind, body=b""):
        frame = struct.pack(">HB", len(body) + 1, kind) + body
        try:
            with self.lock:
                self.sock.sendall(frame)
        except OSError:
            self.close()

    def _read_exact(self, size):
        data = b""
        while len(data) < size:
            chunk = self.sock.recv(size - len(data))
            if not chunk:
                raise OSError("closed")
            data += chunk
        return data

    def _reader(self):
        try:
            while not self.closed:
                (size,) = struct.unpack(">H", self._read_exact(2))
                frame = self._read_exact(size)
                kind, body = frame[0], frame[1:]
                with self.lock:
                    self.latest[kind] = body
                    if kind == ord("I"):
                        try:
                            self.presses |= int(body.split(b",")[1])
                        except (IndexError, ValueError):
                            pass
                self.last_rx = time.monotonic()
        except OSError:
            pass
        self.close()

    def take(self, kind):
        with self.lock:
            return self.latest.pop(kind, None)

    def take_presses(self):
        with self.lock:
            presses, self.presses = self.presses, 0
            return presses

    def peek(self, kind):
        with self.lock:
            return self.latest.get(kind)

    @property
    def alive(self):
        return not self.closed and time.monotonic() - self.last_rx < LINK_TIMEOUT_S

    def close(self):
        if not self.closed:
            self.closed = True
            try:
                self.sock.close()
            except OSError:
                pass


class Matchmaker:
    """Listens and scans until it is paired with the other console."""

    def __init__(self):
        self.link = None
        self.role = None       # "host" or "client"
        self.running = False
        self.server = None
        self.config = {}

    def start(self):
        if self.running:
            return
        self.running = True
        self.link, self.role = None, None
        self.config = load_config()
        forced = self.config.get("role")
        print(f"Online: looking for the other console (my IP {MY_IP or 'unknown'}, role {forced or 'auto'})")
        if forced != "client":
            threading.Thread(target=self._listen, daemon=True).start()
        if forced != "host":
            threading.Thread(target=self._scan, daemon=True).start()

    def stop(self):
        self.running = False
        if self.link:
            self.link.close()
        self.link, self.role = None, None
        if self.server:
            try:
                self.server.close()
            except OSError:
                pass
            self.server = None

    def _paired(self, link, role):
        if self.link is not None:
            link.close()
            return
        self.link, self.role = link, role
        print(f"Online: paired as {role}")

    def _listen(self):
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            server.bind(("0.0.0.0", PORT))
        except OSError as error:
            print(f"Online: cannot listen on {PORT}: {error}")
            return
        server.listen(4)
        server.settimeout(0.5)
        self.server = server
        while self.running and self.link is None:
            try:
                sock, address = server.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            # Scanners of the other console probe and hang up; a client says hello.
            sock.settimeout(2.0)
            try:
                header = sock.recv(3)
            except OSError:
                header = b""
            if len(header) == 3 and header[2] == ord("H"):
                try:  # Drop the hello body so the next frame starts cleanly.
                    remaining = struct.unpack(">H", header[:2])[0] - 1
                    while remaining > 0:
                        remaining -= len(sock.recv(remaining)) or remaining
                except OSError:
                    sock.close()
                    continue
                sock.settimeout(None)
                self._paired(Link(sock), "host")
            else:
                sock.close()
        try:
            server.close()
        except OSError:
            pass

    def _candidates(self):
        peer = self.config.get("peer")
        if peer:
            host, _, port = peer.partition(":")
            return [(host, int(port or PORT))]
        if not MY_IP:
            return []
        network = ipaddress.ip_network(MY_IP + "/24", strict=False)
        return [(str(ip), PORT) for ip in network.hosts() if str(ip) != MY_IP]

    def _probe(self, target):
        try:
            return socket.create_connection(target, timeout=0.4), target
        except OSError:
            return None, target

    def _scan(self):
        forced_client = self.config.get("role") == "client"
        with ThreadPoolExecutor(max_workers=48) as pool:
            while self.running and self.link is None:
                for sock, (ip, port) in pool.map(self._probe, self._candidates()):
                    if sock is None:
                        continue
                    # The lower IP hosts; the higher IP connects as the client.
                    if self.link is None and self.running and (forced_client or ip_key(MY_IP) > ip_key(ip)):
                        sock.settimeout(None)
                        link = Link(sock)
                        link.send(ord("H"), MY_IP.encode())
                        self._paired(link, "client")
                    else:
                        sock.close()
                time.sleep(1.0)


def restore_tilt():
    """Give the sketch the calibration saved by an earlier TILT SETUP."""
    try:
        with open(TILT_FILE) as handle:
            values = json.load(handle)["values"]
    except (OSError, ValueError, KeyError):
        return
    if Bridge.call("ducks_set_tilt", *[int(v) for v in values]):
        print(f"Tilt calibration restored: {values}")


def save_tilt():
    values = [int(v) for v in Bridge.call("ducks_get_tilt").split(",")]
    os.makedirs(DATA_DIR, exist_ok=True)
    with open(TILT_FILE, "w") as handle:
        json.dump({"values": values}, handle)
    print(f"Tilt calibration saved: {values}")


net = Matchmaker()
matched = False
tilt_restored = False
saved_cal = "0"
last_print = 0.0
last_phase = None


def parse_status(text):
    return dict(part.split("=", 1) for part in text.split() if "=" in part)


def loop():
    global matched, last_print, last_phase, tilt_restored, saved_cal
    try:
        status = parse_status(Bridge.call("ducks_status"))
    except Exception as error:
        print(f"Waiting for the game sketch: {error}")
        time.sleep(2)
        return
    phase, mode = status.get("phase"), status.get("mode")

    try:
        if phase not in (None, "SETUP") and not tilt_restored:
            restore_tilt()
            tilt_restored = True
        cal = status.get("cal", "0")
        if cal != saved_cal and cal != "0":
            save_tilt()
            saved_cal = cal
    except Exception as error:
        print(f"Tilt calibration file error: {error}")

    now = time.monotonic()
    if phase != last_phase or now - last_print > 1.0:
        print(" ".join(f"{key}={value}" for key, value in status.items()))
        last_print, last_phase = now, phase

    try:
        if phase == "WAIT":
            net.start()
            if net.link is not None and not matched:
                matched = bool(Bridge.call("ducks_match", 1 if net.role == "host" else 2))
        elif phase in ("TITLE", "SETUP"):
            if net.running:
                net.stop()
            matched = False

        link = net.link
        if mode == "HOST" and link is not None:
            body = link.peek(ord("I")) or b"0,0,0,0,1"
            fields = [int(value) for value in body.split(b",")]
            held, dx, dy = fields[0], fields[2], fields[3]
            remote_ok = fields[4] if len(fields) > 4 else 1
            snapshot = Bridge.call("ducks_host", held, link.take_presses(), dx, dy,
                                   1 if link.alive else 0, remote_ok)
            if snapshot:
                link.send(ord("S"), bytes.fromhex(snapshot))
        elif mode == "CLIENT" and link is not None:
            snapshot = link.take(ord("S")) or b""
            reply = Bridge.call("ducks_client", snapshot, 1 if link.alive else 0)
            if reply:
                link.send(ord("I"), reply.encode())
    except Exception as error:
        print(f"Online relay error: {error}")
        time.sleep(0.5)

    time.sleep(CYCLE_S if mode in ("HOST", "CLIENT") else 0.2)


print("Duck Duck Punch: A = hunt, B = score, C = online, stick click = tilt setup.")
App.run(user_loop=loop)
